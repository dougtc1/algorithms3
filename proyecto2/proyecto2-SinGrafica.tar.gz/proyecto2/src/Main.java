import java.


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author dougtc
 */
public class Main {
    
     public static void main(String[] args) {
         
        int [] resultado = new int [2];
        
        int cantidad;
        
        boolean grafica = true;
        
        String s;
        
        if (args.length == 1) {
            
            s = args[0];
            
            
        } else if ( args.length == 2 && "-q".equals(args[0])) {
            
            s = args[1];
            
            grafica = false;
        
        } else {
            
            System.out.println("El programa fue llamado de forma incorrecta.");
            
            s = args[1];
            
            System.exit(0);
            
        }
            
        Puntos.leerArchivo(s);
        
        cantidad = Puntos.tamano;
        
        Puntos.matrizDistancia();
        
        System.out.println(Puntos.kclusters + " - Clusters // " + cantidad + " - Cantidad");
         
        while(Puntos.kclusters != cantidad) {
         
            resultado = Puntos.minimaDistancia();
         
            int cluster = resultado[0];
            int punto = resultado[1];

            System.out.println("(" + cluster + "," + punto + ")" + " - PUNTO CON DISTANCIA MINIMA" );
            
         
            Puntos.actualizarMatriz(cluster, punto);
            
            cantidad--;         

        }
        
        System.out.println("Matriz de distancias");
        
        for (int i = 0; i < Puntos.tamano; i++) {
            
            
            for (int j = 0; j < Puntos.tamano; j++) {
                
                System.out.print("[");
                System.out.print(Puntos.distancias[i][j]);
                System.out.print("]");
                
            }
            
            System.out.print("\n");
        }
        
        System.out.println(Puntos.kclusters + " - Clusters // " + cantidad + " - Cantidad");
    
    
    if (grafica) {
        
        
        
    }
        
    
    }
} 