/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author dougtc
 */
public class Main {
    
     public static void main(String[] args) {
         
        int [] resultado = new int [2];
        
        int cantidad;
         
        String s = args[0];
        Puntos.leerArchivo(s);
        
        cantidad = Puntos.tamano;
        
        Puntos.matrizDistancia();
         
        while(Puntos.kclusters != cantidad) {
         
            resultado = Puntos.minimaDistancia();
         
            int indX = resultado[0];
            int indY = resultado[1];

            System.out.println(resultado + " RESULTADO");
         
            Puntos.actualizarMatriz(indX, indY);
            
            cantidad--;
            
            System.out.println(resultado + " RESULTADO");
            
         

     }

     }
    
}
