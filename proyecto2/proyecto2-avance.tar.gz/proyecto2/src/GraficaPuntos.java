import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Shape;
import java.util.*;
import javax.swing.JPanel;
import org.jfree.chart.*;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.AbstractRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.util.ShapeUtilities;
import org.jfree.chart.renderer.xy.XYDotRenderer;


/**
 *
 * @author dougtc
 */
public class GraficaPuntos extends ApplicationFrame {
    
    public GraficaPuntos(String s) {
        
        super(s);
        JPanel jpanel = crearPanel();
        jpanel.setPreferredSize(new Dimension(640, 480));
        add(jpanel);
    }
    
    public static XYDataset SetPuntos() {
        
        XYSeriesCollection resultado = new XYSeriesCollection();
    
        for (int i = 0; i < Puntos.arregloClusters.size(); i++) {
            
            resultado = new XYSeriesCollection();
            
            XYSeries serieDePuntos = new XYSeries("Puntos");
            
            Puntos puntoAuxiliar = Puntos.arregloClusters.get(i);
            
            double ordenada = puntoAuxiliar.coordX;
            
            double abcisa = puntoAuxiliar.coordY;
            
            serieDePuntos.add(ordenada, abcisa);
        
            for (int j = 0; j < puntoAuxiliar.adyacentes.size(); i++) {
                
                Puntos puntoAuxiliar2 = puntoAuxiliar.adyacentes.get(j);
                
                double ordenada2 = puntoAuxiliar2.coordX;
            
                double abcisa2 = puntoAuxiliar2.coordY;
                
                serieDePuntos.add(ordenada2, abcisa2);
            
            }
            
            resultado.addSeries(serieDePuntos);
                
            //IMPRIMIR
        
        }
        
    return resultado;
    
    }
        
    
    public static JPanel crearPanel() {

       /* JFreeChart jfreechart = ChartFactory.createScatterPlot("k = " + Puntos.kclusters,
            "X", "Y", SetPuntos(), PlotOrientation.VERTICAL, true, true, false);
        
        Shape cross = ShapeUtilities.createDiagonalCross(1, 3);
        XYDotRenderer circulos = new XYDotRenderer();

        XYPlot xyPlot = (XYPlot) jfreechart.getPlot();
        XYItemRenderer renderer = xyPlot.getRenderer();
        renderer.setBaseShape(cross);
        renderer.setBasePaint(Color.red);
        //changing the Renderer to XYDotRenderer
        //xyPlot.setRenderer(new XYDotRenderer());
        xyPlot.setRenderer(circulos);
        circulos.setSeriesShape(0, cross);
        

        xyPlot.setDomainCrosshairVisible(true);
        xyPlot.setRangeCrosshairVisible(true);

        return new ChartPanel(jfreechart); */
        
        JFreeChart jfreechart = ChartFactory.createScatterPlot("k = " + Puntos.kclusters,
            "X", "Y", SetPuntos(), PlotOrientation.VERTICAL, true, true, false);
        Shape cross = ShapeUtilities.createDiagonalCross(3, 1);

        XYPlot xyPlot = (XYPlot) jfreechart.getPlot();
        XYItemRenderer renderer = xyPlot.getRenderer();
        renderer.setBaseShape(cross);
        renderer.setBasePaint(Color.red);
        //changing the Renderer to XYDotRenderer
        //xyPlot.setRenderer(new XYDotRenderer());
        XYDotRenderer xydotrenderer = new XYDotRenderer();
        xyPlot.setRenderer(xydotrenderer);
        xydotrenderer.setSeriesShape(0, cross);

        xyPlot.setDomainCrosshairVisible(true);
        xyPlot.setRangeCrosshairVisible(true);

        return new ChartPanel(jfreechart);
    }
    
    
}
        