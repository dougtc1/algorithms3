/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @authors Giuli Latella & Douglas Torres
 */
public class Main {
    public static void main(String[] args) {
        Grafo g = new Grafo();
        Recorridos r = new Recorridos(g.obtenerNodos().size(), g);
        r.VerificacionCasa();
    }
}
