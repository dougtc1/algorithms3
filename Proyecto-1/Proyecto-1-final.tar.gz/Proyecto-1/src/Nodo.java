import java.util.ArrayList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Giuli Latella & Douglas Torres
 */
public class Nodo {
    private String nombre;
    ArrayList<Arista> destinos;
    public int numerodfs;
    public int low;
    public int nivel;
    public int numerohijos;
    
    public Nodo(String s){
        this.nombre = s;
        destinos = new ArrayList<Arista>();
        this.numerodfs = -1;
        this.low = -1;
        this.nivel = 0;
        this.numerohijos = 0;
    }

    public String obtenerNombre() {
        return nombre;
    }

    public ArrayList<Arista> obtenerAristas(){
        return destinos;
    }
    
    public void agregarArista(Nodo destino){
        destinos.add(new Arista(destino));
    }
    
    @Override
    public String toString() {
        return nombre; 
    }
    
}
